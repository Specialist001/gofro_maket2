/**
 * @author mrdoob / http://mrdoob.com
 */

class Source {

	constructor( dom ) {

		this.dom = dom;

	}

	setText( text ) {

		this.dom.textContent = text;

	}

}
